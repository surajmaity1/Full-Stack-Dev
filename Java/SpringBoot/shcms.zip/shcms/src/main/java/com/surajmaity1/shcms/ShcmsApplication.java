package com.surajmaity1.shcms;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShcmsApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShcmsApplication.class, args);
	}

}
