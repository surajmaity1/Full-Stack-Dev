package com.example.testingservice;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestingServiceApplicationTests {

	@Test
	void contextLoads() {
	}

}
