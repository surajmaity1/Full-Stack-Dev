package com.surajmaity1.txtmsg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TxtmsgApplicationTests {

	@Test
	void contextLoads() {
	}

}
